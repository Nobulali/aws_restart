print("Python has three numeric types: int, float, and complex")
myValue=1
print(str(myValue) + " is of the data type " + str(type(myValue)))
myValue=3.14
print(str(myValue) + " is of the data type " + str(type(myValue)))
myValue=5j
print(str(myValue) + " is of the data type " + str(type(myValue)))
myValue=True
print(str(myValue) + " is of the data type " + str(type(myValue)))
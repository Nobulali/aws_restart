myFinalAnswerTuple= ('apple', 'banana', 'cherries')
print(myFinalAnswerTuple)
print(type(myFinalAnswerTuple))

print(myFinalAnswerTuple[0])
print(myFinalAnswerTuple[1])
print(myFinalAnswerTuple[2])

# myFinalAnswerTuple[2]= 'orange'
# print(myFinalAnswerTuple)
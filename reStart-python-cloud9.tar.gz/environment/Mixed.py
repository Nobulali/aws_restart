myMixedTypeList = [45, 290578, 1.02, True, "My dog is on the bed.", "45", 103, 122.56, "Demo text"]
# print(myMixedTypeList[0])
# print(myMixedTypeList[1])
# print(myMixedTypeList[2])
# print(myMixedTypeList[3])
# print(myMixedTypeList[4])
# print(myMixedTypeList[5])
# print(myMixedTypeList[6])
# print(myMixedTypeList[7])
# print(myMixedTypeList[8])

for item in myMixedTypeList:#for loop
    print("{}".format(item))
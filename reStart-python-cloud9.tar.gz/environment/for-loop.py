myString="This is an example of String"

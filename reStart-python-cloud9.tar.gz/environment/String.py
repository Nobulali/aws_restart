myString="This is my string"
print(myString)
print
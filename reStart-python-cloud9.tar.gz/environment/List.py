myFruitList= ['apple', 'banana', 'cherries']
print(myFruitList)
print(type(myFruitList))

print(myFruitList[0])
print(myFruitList[1])
print(myFruitList[2])

myFruitList[2]= 'orange'
print(myFruitList)
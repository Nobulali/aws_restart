myFavouriteFruitDictionary= {
    "ap" : "apple",
    "ba" : "banana",
    "pi" : "pineapple"
}

print(myFavouriteFruitDictionary)
print(type(myFavouriteFruitDictionary))

print(myFavouriteFruitDictionary["ap"])
print(myFavouriteFruitDictionary["ba"])
print(myFavouriteFruitDictionary["pi"])

myFavouriteFruitDictionary["ba"]= 'orange'
print(myFavouriteFruitDictionary)
